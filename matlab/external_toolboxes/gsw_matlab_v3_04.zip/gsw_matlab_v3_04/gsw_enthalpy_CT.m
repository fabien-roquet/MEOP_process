function enthalpy = gsw_enthalpy_CT(SA,CT,p)

% gsw_enthalpy                                specific enthalpy of seawater
%                                                        (48-term equation)
%==========================================================================
% This function has changed name to gsw_enthalpy
%==========================================================================

warning('This function has changed name to gsw_enthalpy')

enthalpy = gsw_enthalpy(SA,CT,p);

end
