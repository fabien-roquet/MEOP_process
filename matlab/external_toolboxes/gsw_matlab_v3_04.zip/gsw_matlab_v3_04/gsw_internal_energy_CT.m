function internal_energy = gsw_internal_energy_CT(SA,CT,p)

% gsw_internal_energy                   specific interal energy of seawater
%                                                        (48-term equation)
%==========================================================================
% This function has changed name to gsw_internal_energy
%==========================================================================

warning('This function has changed name to gsw_internal_energy')

internal_energy = gsw_internal_energy(SA,CT,p);

end
