function gsw_contents

% Contents of the Gibbs SeaWater (GSW) Oceanographic Toolbox of TEOS-10 

showdemo gsw_contents

end